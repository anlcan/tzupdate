sudo java -jar tzupdater.jar  -l file://`pwd`/tzdata2016g.tar.gz
